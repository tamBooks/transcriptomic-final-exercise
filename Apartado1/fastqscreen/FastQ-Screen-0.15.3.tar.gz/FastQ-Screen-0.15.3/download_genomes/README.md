This folder contains details on the downloaded regular (Bowtie2) and bisulphite genomes (Bismark/Bowtie2), should they need to be re-made / uploaded at some future date.

This folder contains a tree of the files on the remote FTP, the regular/bisulphite configuration files downloaded from the FTP and the FTP location file downloaded from the Babraham server.
